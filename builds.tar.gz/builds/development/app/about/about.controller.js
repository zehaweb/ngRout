(function() {
    'use strict';

    angular
        .module('ngFit.about', ['ngRoute'])
        .config(configAbout)
        .controller('AboutCtrl', AboutCtrl);


    configAbout.$inject = ['$rootScope'];

    function AboutCtrl($rootScope) {
        var about = this;

        $rootScope.curPath = 'about';

        about.title = 'About page'
    };



    configAbout.$inject = ['$routeProvider'];

    function configAbout($routeProvider) {
        $routeProvider
            .when('/about', {
                templateUrl: "app/about/about.html",
                controller: 'AboutCtrl',
                controllerAs: 'about'
            })
    }


})();
