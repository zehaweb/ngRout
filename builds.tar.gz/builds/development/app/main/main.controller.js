
(function() {
    'use strict';

    angular
        .module('ngFit.main', ['ngRoute'])
        .config(configMain)
        .controller('MainCtrl', MainCtrl);

    configMain.$inject = ['$rootScope'];

    function MainCtrl($rootScope) {
        var main =  this;

        $rootScope.curPath = 'main';


        main.title = 'Home page'
    };



    configMain.$inject = ['$routeProvider'];

    function configMain($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: "app/main/main.html",
                controller: 'MainCtrl',
                controllerAs: 'main'

            })
    }

})();
