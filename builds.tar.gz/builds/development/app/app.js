// initialize material design js
$.material.init();

(function() {
    'use strict';

angular
    .module('ngFit', ['ngRoute','ngFit.about','ngFit.contact','ngFit.main'])
    .config(ngConfig);

    ngConfig.$inject = ['$routeProvider'];

    function ngConfig($routeProvider) {
        $routeProvider
            .otherwise({ redirectTo: '/' })
    }



})();
