(function() {
    'use strict';

    angular
        .module('ngFit.contact', ['ngRoute'])
        .config(configContact)
        .controller('ContactCtrl', ContactCtrl);

    configContact.$inject = ['$rootScope'];


    function ContactCtrl($rootScope) {
        var cont = this;

        $rootScope.curPath = 'contact';


        cont.title = 'Contact page132'
    };



    configContact.$inject = ['$routeProvider'];

    function configContact($routeProvider) {
        $routeProvider
            .when('/contact', {
                templateUrl: "app/contact/contact.html",
                controller: 'ContactCtrl',
                controllerAs: 'cont'

            })
    }






})();
